# AnDet Pro - results to paste into the thesis and the slides

**Run:** `20261029_021641_standard`  |  **Mode:** standard  |  **Started:** 2026-10-29T02:16:42  |  **Seed:** 42
**Computer:** Linux-6.6.159+-x86_64-with-glibc2.39  |  **TensorFlow:** 2.21.0  |  **GPU:** /physical_device:GPU:0

How to use this file: open the thesis next to it. Section 4.4.6 of the thesis becomes **Run 2: The Complete Evaluation** and receives these tables (suggested numbers: Table 4.7 data, 4.8 model and threshold, 4.9 results, 4.10 requirements, 4.11 false alarm checks; Figure 4.5 results against targets). Copy a table, or use the draft sentences. `DOCUMENT_UPDATE_SHEET.md` lists every other place that shows a Run 1 number.

## What changed since Run 1 (say this in Section 4.4.1)

* The baseline is **run as software on the same traffic** (a fixed 3-sigma rule on rolling means). Only the time a person takes to review an alert is assumed (38 s with SD 5 s, carried over from Run 1).
* **Every trial is saved**, so the detection rate and the time to detect are reported separately.
* The alert threshold is set on **held-out normal windows**, not on the training windows.
* The scaler is learned from the training block only (no test information).
* **Containment** is worked out from the rules the policy engine produces, by replaying the attack flows against them.
* All flows in the trials are **real flows** from the test part; one flow = one time step of 1 s (an assumption).

## 1. Data used (Table 4.3 in Run 1)

| Item | Value |
|---|---|
| Data set | NF-CSE-CIC-IDS2018.parquet |
| Flows in the full file | 5,918,803 |
| Flows in the sample | 100,319 (every 59th flow, in time order) |
| Features (10) | L4_SRC_PORT, L4_DST_PORT, PROTOCOL, L7_PROTO, IN_BYTES, OUT_BYTES, IN_PKTS, OUT_PKTS, TCP_FLAGS, FLOW_DURATION_MILLISECONDS |
| Split | First 70% in time for training, last 30% for testing |
| Normal flows available for training | 69,141 (1,082 attack flows in the training part were left out) |
| Normal flows by use | fit 48,399; validation 10,371; calibration (threshold) 10,371 |
| Training windows | 48,340 (stride 1); validation 10,312; calibration 10,312 |
| Test flows | 30,096, of which 18.2% are attacks |

## 2. Model and threshold settings (Table 4.4 in Run 1)

| Item | Setting |
|---|---|
| VMD | K = 5 modes, α = 2000, tolerance 1e-07, mirrored edges, start frequencies uniform, scope: stream |
| Window | 60 time steps by 5 values |
| Encoder | LSTM with 128 units (dropout 0.2), then LSTM with 64 units (the bottleneck) |
| Decoder | Repeat the bottleneck 60 times, LSTM with 64 units, LSTM with 128 units, one dense layer with 5 outputs per step |
| Parameters | 250,501 |
| Training | Adam, learning rate 0.001, batch size 64, at most 100 epochs; 100 epochs run (reached the maximum); best epoch 97; 25.2 minutes |
| Loss | training 2.1088e-04 (epoch 1) to 9.5444e-05 (best epoch); validation 9.8746e-05 to 8.8793e-05 |
| Threshold | set on 10,312 held-out normal windows: μ = 8.840e-05, σ = 3.032e-05, Θ = μ + 3σ = 1.794e-04. CRITICAL above 2Θ = 3.587e-04 |
| False alarm rate on the calibration windows | 0.72% |
| Random seed | 42 |
| Computer | Linux-6.6.159+-x86_64-with-glibc2.39; GPU: /physical_device:GPU:0; TensorFlow 2.21.0 |

Draft sentence for Section 4.2.2: *The training loss fell from 2.1088e-04 in epoch 1 to 9.5444e-05 in epoch 97. The validation loss fell from 9.8746e-05 to 8.8793e-05 over the same epochs. Training ran for the maximum of 100 epochs and took 25.2 minutes.*

## 3. Results (Table 4.5 in Run 1) - 300 trials per condition

SD is the standard deviation over the trials. For MTTD, MTTR and FPR the t value and Cohen's d are *baseline minus AnDet Pro*, so a positive value means AnDet Pro is better. For the detection rate and containment, z and h are *AnDet Pro minus baseline*, so a positive value again means AnDet Pro is better. Change is relative for times and in percentage points for rates.

| Measure | Baseline (SD) | AnDet Pro (SD) | Change | Test | Effect size |
|---|---|---|---|---|---|
| MTTD (s), detected attacks only | 51.53 (64.63) | 37.00 (35.31) | −28.2% | t(392.3) = 3.10, p = 0.002 | 0.28 (small) |
| MTTR (s), attacks with a response | 89.94 (64.89) | 37.00 (35.31) | −58.9% | t(391.3) = 11.27, p < 0.001 | 1.01 (large) |
| FPR (%) | 22.92 (38.70) | 2.83 (6.63) | −20.1 points | t(316.5) = 8.86, p < 0.001 | 0.72 (medium) |
| Detection rate (%) | 83.7  (251/300) | 78.3  (235/300) | −5.3 points | z = −1.67, p = 0.096 | h = −0.14 |
| Containment (%) | 75.3  (226/300) | 75.0  (225/300) | −0.3 points | z = −0.09, p = 0.925 | h = −0.01 |

More detail (confidence intervals, other tests, misses counted, new-alert variants):

| Measure | n baseline | n AnDet Pro | Difference (the label says which way) | 95% CI of the difference | p (Welch / z) | p (Mann-Whitney / Fisher) | p (paired) | p (Holm) |
|---|---|---|---|---|---|---|---|---|
| MTTD (s), detected attacks only | 251 | 235 | 14.53 s | 5.32 to 23.74 | p = 0.002 | p = 0.009 | p < 0.001 | p = 0.004 |
| MTTR (s), attacks with a response | 251 | 235 | 52.94 s | 43.70 to 62.18 | p < 0.001 | p < 0.001 | p < 0.001 | p < 0.001 |
| MTTD (s), a missed attack counts as the whole attack period | 300 | 300 | 3.46 s | −8.97 to 15.89 | p = 0.584 | p = 0.004 | - | - |
| MTTR (s), a missed attack counts as the whole attack period | 300 | 300 | 35.60 s | 23.88 to 47.32 | p < 0.001 | p < 0.001 | - | - |
| MTTD (s), only NEW alerts count (an alarm already on at the start does not) | 196 | 229 | 32.26 s | 21.72 to 42.80 | p < 0.001 | p = 0.004 | - | - |
| FPR per trial (fraction) | 300 | 300 | 0.201 | 0.156 to 0.245 | p < 0.001 | p < 0.001 | - | p < 0.001 |
| Share of all attack flows dropped by the rules (AnDet Pro minus baseline) | 300 | 300 | 0.158 | 0.102 to 0.215 | p < 0.001 | p < 0.001 | - | - |
| Detection rate (AnDet Pro minus baseline) | 300 | 300 | −0.053 | −0.116 to 0.010 | p = 0.096 | Fisher p = 0.118 | - | - |
| Detection rate, only NEW alerts count (AnDet Pro minus baseline) | 300 | 300 | 0.110 | 0.037 to 0.181 | p = 0.003 | Fisher p = 0.004 | - | - |
| Containment (AnDet Pro minus baseline) | 300 | 300 | −0.003 | −0.072 to 0.066 | p = 0.925 | Fisher p = 1.000 | - | p = 0.925 |
| Alarm already on when the attack starts (AnDet Pro minus baseline) | 300 | 300 | −0.207 | −0.260 to −0.154 | p < 0.001 | Fisher p < 0.001 | - | - |

Hypotheses (Section 3.6.3):

| Hypothesis | Statement | Difference in favour of AnDet Pro | p | p (Holm) | Result at 5% |
|---|---|---|---|---|---|
| H1 | AnDet Pro has a lower MTTD than the baseline | 14.530 | p = 0.002 | p = 0.004 | Supported |
| H2 | AnDet Pro has a lower MTTR than the baseline | 52.941 | p < 0.001 | p < 0.001 | Supported |
| H3 | AnDet Pro has a lower false positive rate than the baseline | 0.201 | p < 0.001 | p < 0.001 | Supported |
| H4 | AnDet Pro has a higher containment rate than the baseline | −0.003 | p = 0.925 | p = 0.925 | Not supported (worse, not significant) |

## 4. Requirements check (Table 4.6 in Run 1)

| No. | Target | Result in this run | Status |
|---|---|---|---|
| NFR-01 | MTTD below 20 s | 37.00 s (detection rate 78.3%) | Not met |
| NFR-02 | MTTR below 25 s | 37.00 s | Not met |
| NFR-03 | False positive rate below 5% | 2.8% | Met |
| NFR-04 | Containment above 90% | 75.0% | Not met |
| NFR-05 | Scoring of one window within 50 ms | 25.4 ms median, 123.4 ms 95th percentile (VMD + model + policy, this computer) | Met |
| NFR-06 | Rule installed within 15 ms | Not measured (simulation mode). The engine itself needs 0.009 ms to create the rules. | Open |
| NFR-07 | Up to 1,000 hosts | Not tested | Open |
| NFR-08 | At most 30 s of downtime per day | Not tested | Open |
| NFR-09 | Documented seed for random steps | Seed 42 (training); trial seeds start at 1000 | Met |
| NFR-10 | HTTPS link to the controller | Not tested (simulation mode) | Open |

Draft sentence for Section 4.4.3: *Three of the ten requirements were met, three were missed and four were not measured.*

## 5. Draft wording for Section 4.4.2 (edit before use)

**MTTD.** AnDet Pro raised an alert for 235 of 300 attacks (78.3%) and the baseline for 251 of 300 (83.7%). For the detected attacks the mean time to detect was 37.00 s (SD 35.31) for AnDet Pro and 51.53 s (SD 64.63) for the baseline, a change of −28.2% (p = 0.002, d = 0.28). The 95% confidence interval of the difference is 5.32 to 23.74 s. The target of 20 s was missed.

**MTTR.** The response was in place after 37.00 s (SD 35.31) against 89.94 s (SD 64.89) for the baseline (−58.9%, p < 0.001, d = 1.01). The target of 25 s was missed. In simulation mode the rules are only written to a log, so the time to install a rule in a real switch was not measured. The baseline time includes the assumed review time of a person (38 s on average).

**False positive rate.** The mean rate per trial was 2.8% (SD 6.6) for AnDet Pro and 22.9% (SD 38.7) for the baseline (p < 0.001, d = 0.72). Counted over all normal windows the rates are 2.8% (95% CI 2.7 to 3.0) and 22.9% (95% CI 22.6 to 23.2). The target of 5% was met. In 0.0% of the AnDet Pro trials at least half of the normal windows were flagged (baseline: 19.7%), so false alarms came in bursts and not evenly (see the table of false alarms by part of the stream).

**Containment.** AnDet Pro contained 225 of 300 attacks (75.0%, 95% CI 69.8 to 79.6) and the baseline 226 of 300 (75.3%, 95% CI 70.2 to 79.9); difference −0.3 points (p = 0.925, Cohen's h = −0.01). An attack counts as contained when a blocking rule is in place and at least 90% of the attack flows that arrive after that moment are dropped. The target of 90% was missed. The data set has no IP addresses, so the alert is assumed to name the true attacker: the figure is an upper bound and harm to normal users is not measured.

## 6. What the evidence says about the false alarms (Section 4.4.4)

| Check | Value |
|---|---|
| False alarm rate on the held-out calibration windows (the threshold was set here) | 0.72% |
| False alarm rate on normal windows of the real test stream | 0.53% |
| Baseline, same windows | 11.91% |
| False alarm rate on normal windows more than one window length (60 flows) away from any attack (19,167 windows) | 0.55% |
| False alarm rate on normal windows within one window length of an attack (780 windows) | 0.00% |
| Trials, windows before the first attack flow (54,300 windows): false alarms with VMD on the whole stream (as in the evaluation) | 2.81% |
| Same windows, VMD computed from past flows only (no look-ahead) | 6.52% |
| Recall of attack windows (real test stream) | 0.6% |
| AUROC, AnDet Pro (baseline) | 0.147 (0.918) |
| Trials in which at least half of the normal windows were flagged, AnDet Pro (baseline) | 0.0% (19.7%) |
| Trials in which an alarm was already on when the attack started, AnDet Pro (baseline) | 3.3% (24.0%) |

False alarm rate on normal windows, by part of the test stream:

| Part | Normal windows | AnDet Pro FPR (%) | Baseline FPR (%) | Attack windows (%) |
|---|---|---|---|---|
| 1 | 2455 | 0.0 | 2.4 | 11.6 |
| 2 | 3004 | 0.0 | 1.8 | 0.0 |
| 3 | 3004 | 0.0 | 1.2 | 0.0 |
| 4 | 3004 | 0.0 | 1.9 | 0.0 |
| 5 | 2350 | 3.4 | 4.2 | 0.5 |
| 6 | 3004 | 0.9 | 6.0 | 0.0 |
| 7 | 1246 | 0.0 | 0.9 | 55.4 |
| 8 | 0 | n/a | n/a | 100.0 |
| 9 | 1687 | 0.0 | 100.0 | 42.7 |
| 10 | 193 | 0.0 | 100.0 | 92.1 |

Draft wording: *The threshold fits the data it was set on (0.72% of calibration windows are flagged), yet 0.5% of the normal windows of the test stream are flagged. Away from attacks the rate is low (0.6%), so false alarms are not a problem in quiet traffic. None of these checks isolates a single cause, so each cause named here is a likely one, not a finding.*

### Threshold sweep (replaces the 'threshold sweep' promised in Section 4.4.6)

| Threshold | Θ | FPR calibration (%) | FPR test stream (%) | Recall test stream (%) | F1 | Detection rate trials (%) | MTTD trials (s) | FPR trials (%) | Containment trials (%) |
|---|---|---|---|---|---|---|---|---|---|
| mu + 1 sigma | 1.187e-04 | 15.4 | 12.3 | 4.0 | 0.061 | 87.7 | 20.73 | 27.2 | 80.0 |
| mu + 2 sigma | 1.490e-04 | 2.7 | 2.2 | 0.8 | 0.016 | 83.0 | 31.43 | 9.5 | 77.7 |
| mu + 3 sigma **(used)** | 1.794e-04 | 0.7 | 0.5 | 0.6 | 0.012 | 78.3 | 37.00 | 2.8 | 75.0 |
| mu + 4 sigma | 2.097e-04 | 0.1 | 0.2 | 0.5 | 0.009 | 72.3 | 47.72 | 0.7 | 69.7 |
| mu + 5 sigma | 2.400e-04 | 0.0 | 0.0 | 0.1 | 0.003 | 68.3 | 61.67 | 0.2 | 65.7 |
| mu + 6 sigma | 2.703e-04 | 0.0 | 0.0 | 0.0 | n/a | 65.3 | 76.36 | 0.1 | 62.3 |
| mu + 8 sigma | 3.310e-04 | 0.0 | 0.0 | 0.0 | n/a | 44.3 | 86.69 | 0.0 | 41.7 |
| mu + 10 sigma | 3.916e-04 | 0.0 | 0.0 | 0.0 | n/a | 25.0 | 92.95 | 0.0 | 23.7 |
| 99th percentile of calibration | 1.716e-04 | 1.0 | 0.7 | 0.7 | 0.013 | 79.3 | 34.68 | 4.0 | 76.7 |
| 99.5th percentile of calibration | 1.832e-04 | 0.5 | 0.4 | 0.6 | 0.012 | 77.7 | 38.79 | 2.3 | 74.7 |
| 99.9th percentile of calibration | 2.197e-04 | 0.1 | 0.0 | 0.4 | 0.009 | 71.3 | 53.01 | 0.4 | 68.3 |

Baseline rule, different fixed limits:

| Rule | FPR test stream (%) | Recall test stream (%) | Detection rate trials (%) | MTTD trials (s) | FPR trials (%) | Containment trials (%) |
|---|---|---|---|---|---|---|
| z > 2 | 20.1 | 97.7 | 100.0 | 10.38 | 30.4 | 100.0 |
| z > 3 **(used)** | 11.9 | 97.1 | 83.7 | 51.53 | 22.9 | 75.3 |
| z > 4 | 9.8 | 70.8 | 50.0 | 38.97 | 20.5 | 43.3 |
| z > 5 | 9.1 | 62.6 | 45.7 | 33.69 | 19.8 | 40.3 |
| z > 6 | 8.4 | 53.6 | 44.7 | 34.90 | 19.2 | 39.3 |
| z > 8 | 6.2 | 36.5 | 42.7 | 43.18 | 16.8 | 37.7 |

## 7. Replay of the real test stream (no injected attacks)

Windows: 30,037. A window counts as an attack window when at least 20% of its flows are attacks (9,079 windows), as normal when it has none (19,947); 1,011 windows in between are left out.

| Measure | AnDet Pro | Static baseline |
|---|---|---|
| AUROC | 0.147 | 0.918 |
| AUPRC | 0.197 | 0.717 |
| Recall | 0.006 | 0.971 |
| Precision | 0.346 | 0.788 |
| F1 | 0.012 | 0.870 |
| False positive rate | 0.005 | 0.119 |

How the risk score depends on how much of the window is attack (Risk / Θ above 1 raises an alert):

| Window contains | Windows | Risk / Θ (median) | Share above Θ (%) | Baseline: share above its limit (%) | Movement inside the window |
|---|---|---|---|---|---|
| Normal (no attack flow) | 19,947 | 0.446 | 0.5 | 11.9 | 0.0087 |
| Mostly normal (under 20% attack) | 1,011 | 0.536 | 0.0 | 14.6 | 0.0098 |
| Mixed (20% to 80% attack) | 8,049 | 0.155 | 0.6 | 96.8 | 0.0047 |
| Mostly attack (80% to under 100%) | 910 | 0.145 | 1.1 | 100.0 | 0.0062 |
| Only attack flows | 120 | 0.021 | 0.0 | 100.0 | 0.0018 |

"Movement inside the window" is the average standard deviation of the 5 input channels over the 60 steps of a window. A model that rebuilds windows scores smooth windows low and irregular windows high.

**Read this before writing Section 4.4.4 and Chapter Five.** On the real test stream the risk score ranks attack windows *below* normal windows (AUROC 0.147, where 0.5 means no ranking at all and the baseline reaches 0.918). At the threshold only 0.6% of the attack windows raise an alert. The table above shows the likely reason: windows that are mostly attack move less than normal windows, so the model rebuilds them with a smaller error. In this data a long run of near-identical attack flows is smoother than ordinary traffic. The injected trials of Section 3 mix attack flows with normal flows, which makes the window irregular and is why they are detected. This is a limit of reconstruction-error detection, not a fault of the program: report it in Section 4.4.5, and say in Chapter Five that AnDet Pro finds attacks that make traffic irregular and may miss floods of identical flows. The cause named here is a likely one; this run does not isolate it. The density sweep of `--mode full` (attack share 10% to 100% of the flows) shows where detection starts to fail.

By attack type (attack windows whose main attack type is shown):

| Attack type | Windows | AnDet Pro recall (%) | Risk / Θ (median) | Baseline recall (%) |
|---|---|---|---|---|
| DoS attacks-Hulk | 3560 | 0.0 | 0.16 | 100.0 |
| SSH-Bruteforce | 1762 | 0.0 | 0.12 | 100.0 |
| DDoS attacks-LOIC-HTTP | 1133 | 0.3 | 0.53 | 100.0 |
| DoS attacks-GoldenEye | 980 | 0.0 | 0.08 | 100.0 |
| DoS attacks-SlowHTTPTest | 490 | 0.0 | 0.02 | 100.0 |
| DoS attacks-Slowloris | 464 | 0.0 | 0.15 | 100.0 |
| Infilteration | 365 | 0.0 | 0.50 | 28.5 |
| FTP-BruteForce | 271 | 0.0 | 0.03 | 100.0 |
| DDOS attack-LOIC-UDP | 54 | 98.1 | 1.26 | 100.0 |

## 8. Extra checks

| Model | Window | Channels | Parameters | Epochs | AUROC | FPR test stream (%) | Recall (%) | Detection rate trials (%) | MTTD trials (s) | FPR trials (%) | Containment trials (%) |
|---|---|---|---|---|---|---|---|---|---|---|---|
| AnDet Pro (VMD + LSTM), main run | 60 | 5 | 250,501 | 100 | 0.147 | 0.5 | 0.6 | 78.3 | 37.00 | 2.8 | 75.0 |
| Without VMD (raw features into the LSTM) | 60 | 10 | 253,706 | 36 | 0.839 | 9.5 | 80.2 | 92.7 | 19.20 | 15.6 | 91.0 |

## 9. Speed of scoring one window (NFR-05)

| Step | Median (ms) | 95th percentile (ms) |
|---|---|---|
| VMD of one window | 19.3 | - |
| LSTM model | 6.0 | 7.3 |
| VMD + model + policy engine | 25.4 | 123.4 |
| Batch scoring | 30061 windows per second | - |

This is wall-clock time on the computer that ran the evaluation. Say which computer (Table 4.1).

## 10. Numbers for the slides

The charts on the slides are real PowerPoint charts: right-click, *Edit Data*, and type the numbers below.

| Slide | Item | Baseline | AnDet Pro | Change |
|---|---|---|---|---|
| 16, 17, 19, 20 | MTTD (s) | 51.53 | 37.00 | −28.2% |
| 16, 17, 19, 20 | MTTR (s) | 89.94 | 37.00 | −58.9% |
| 16, 18, 19, 20 | False positive rate (%) | 22.9 | 2.8 | −20.1 points |
| 16, 18, 19, 20 | Containment (%) | 75.3 | 75.0 | −0.3 points |
| 16, 19 | Detection rate (%) | 83.7 | 78.3 | −5.3 points |
| 19 | Trials per condition | 300 | 300 |  |
| 22 | Requirements met / missed / open |  | 3 / 3 / 4 |  |

## 11. Time taken

| Step | Seconds |
|---|---|
| 1. Read and split the data | 1.2 |
| 2. Build features and train the main model | 1,630.8 |
| 3. Time needed to score one window (NFR-05) | 7.4 |
| 4. Replay the real test stream (no injected attacks) | 0.9 |
| 5. Head-to-head trials: AnDet Pro against the static baseline | 102.1 |
| 6. Threshold sweep | 4.2 |
| 7. Extra checks (1 more models) | 561.4 |

## 12. Figures made for you

* `figures/fig_training_curve.png`
* `figures/fig_results_vs_targets.png`
* `figures/fig_risk_distribution.png`
* `figures/fig_roc_curves.png`
* `figures/fig_threshold_sweep.png`
* `figures/fig_detect_times.png`
* `figures/fig_fpr_by_segment.png`
* `figures/fig_vmd_example.png`
