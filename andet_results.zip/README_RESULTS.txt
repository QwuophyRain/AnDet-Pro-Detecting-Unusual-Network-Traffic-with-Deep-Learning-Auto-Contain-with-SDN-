Open these two files first:
  RESULTS_FOR_THESIS.md        tables and draft sentences for Chapter Four, numbers for the slides
  DOCUMENT_UPDATE_SHEET.md     every place in the thesis and the slides that must change

Other folders:
  tables/    every table as a CSV file (opens in Excel)
  records/   TRIAL_RESULT, POLICY_ACTION, WINDOW_and_RISK_SCORE, RUN (the records of thesis Table 3.7)
  figures/   PNG charts
  models/    the trained models and their training history
