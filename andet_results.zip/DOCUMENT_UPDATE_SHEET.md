# Where the thesis and the slides change after this run

Run `20261029_021641_standard`, mode standard, 29 October 2026.

## 0. How to add this run (read first)

The thesis already calls the first test **Run 1** and promises "the complete evaluation" in Section 4.4.6. The simplest honest way to finish is:

1. **Keep Sections 4.4.1 to 4.4.5 as they are.** They are a true record of Run 1.
2. **Turn Section 4.4.6 into "4.4.6 Run 2: The Complete Evaluation"** and put this run's tables, figures and sentences there (Part B).
3. **Change the headline numbers to Run 2** in the Abstract, Chapter One, the chapter summary, Chapter Five and the slides (Part A).
4. Make the small wording changes in Part C.
5. Update the slides (Part D) and press Ctrl+A, then F9 in Word so the contents list and the lists of figures and tables are rebuilt.

If you would rather replace Run 1 completely, overwrite each Run 1 number in Sections 4.2 to 4.4 with the Run 2 number and delete the "In Run 1" sentences. That is more work and it hides why the method changed, so it is not recommended.

## A. Headline places: change these to the Run 2 numbers

| Where | Now says (Run 1) | Change to (Run 2) |
|---|---|---|
| Abstract (data and trials) | tested on a sample of 100,319 flows ... compared with a static zero-trust baseline in 300 trials per condition. The baseline values were taken from published studies. | tested on a sample of 100,319 flows ... compared, in 300 trials per condition, with a static zero-trust baseline that was run as software on the same traffic. Only the time a person takes to review an alert was assumed. |
| Abstract (results) | AnDet Pro cut the mean time to detect from 38.98 to 21.52 seconds and the mean time to respond from 77.13 to 21.53 seconds (both p < 0.001), and it raised containment from 5.0% to 65.0%. However, the false positive rate rose from 21.0% to 37.0%, and three of the four performance targets were missed. | 78.3% of the attacks raised an alert with AnDet Pro and 83.7% with the baseline. The mean time to detect fell from 51.53 s to 37.00 s (−28.2%, p = 0.002). The mean time to respond fell from 89.94 s to 37.00 s (−58.9%, p < 0.001). Containment fell from 75.3% to 75.0% (p = 0.925). The false positive rate fell from 22.9% to 2.8% (p < 0.001). 1 of the four performance targets were met. (Choose the verbs cut / raised / rose / fell and the word However to fit the direction of each number.) |
| Abstract (cause) | A likely cause is the way the alert threshold was set, and the thesis explains how this can be tested. | The false alarm rate was 0.7% on held-out calibration windows and 0.5% on normal windows of the real test stream; in 0.0% of the trials at least half of the normal windows were flagged. (Say "likely" for any cause the checks did not prove.) |
| 1.4 Justification (financial risk paragraph) | In the tests, AnDet Pro cut the MTTD by 44.8%, from 38.98 to 21.52 seconds per event, which points toward a narrower exposure window and a lower cost per incident. | In the tests, the MTTD fell from 51.53 s to 37.00 s (−28.2%, p = 0.002). (Keep "which points toward a narrower exposure window" only if the MTTD fell.) |
| 1.4 Justification (mixed results paragraph) | the false positive rate rose from 21.0% to 37.0% instead of falling ... Setting the threshold on held-out data and testing with and without VMD are the ways identified to address this before any production use (Section 4.4.4). | In Run 2 the false positive rate fell from 22.9% to 2.8% (p < 0.001). The threshold on held-out data and the test with and without VMD were carried out in Section 4.4.6. |
| 1.7 Limitations (data set scope) | The evaluation used a sample of 100,319 flows, which is 1.7% of the file. | Run 2 used a sample of 100,319 flows, which is 1.7% of the file. |
| 1.7 Limitations (modelled baseline) | The static baseline was modelled from published values and was not run on the same traffic, and the attack events in the trials were injected. | In Run 1 the baseline was modelled from published values. In Run 2 it was run as software on the same traffic; only the time a person takes to review an alert (38 s on average, SD 5 s) is assumed. The attack events were injected into real normal traffic. |
| 4.0 Introduction | The results are from Run 1, carried out on 2 October 2026. | The results are from Run 1, carried out on 2 October 2026, and Run 2, carried out on 29 October 2026. |
| 4.5 Chapter Summary | In Run 1 it detected attacks faster than a modelled static baseline (MTTD −44.8%) and responded much faster (MTTR −72.1%), and it contained more attacks (65.0% against 5.0%). Its false positive rate was higher (37.0% against 21.0%), and it missed three of the four performance targets. A likely cause is the way the threshold was set. Run 1 has clear limits, and the complete evaluation package addresses them. | Add: In Run 2, with the baseline run as software on the same traffic, the MTTD fell from 51.53 s to 37.00 s (−28.2%, p = 0.002), the MTTR fell from 89.94 s to 37.00 s (−58.9%, p < 0.001), containment fell from 75.3% to 75.0% (p = 0.925) and the false positive rate fell from 22.9% to 2.8% (p < 0.001). 1 of the four performance targets were met. |
| 5.1 Summary of the Study | It was tested on a sample of 100,319 flows ... in 300 trials per condition (Run 1). AnDet Pro cut MTTD by 44.8% and MTTR by 72.1%, and raised containment from 5.0% to 65.0%. Its false positive rate rose from 21.0% to 37.0%. Two of the ten non-functional requirements were met, three were missed and five were not measured. | It was tested on a sample of 100,319 flows from the NF-CSE-CIC-IDS2018 data set and compared with a static zero-trust baseline in 300 trials per condition (Run 2). The MTTD fell from 51.53 s to 37.00 s (−28.2%, p = 0.002); the MTTR fell from 89.94 s to 37.00 s (−58.9%, p < 0.001); containment fell from 75.3% to 75.0% (p = 0.925); the false positive rate fell from 22.9% to 2.8% (p < 0.001). 3 of the ten non-functional requirements were met, 3 were missed and 4 were not measured. |
| Table 5.1, O1 evidence | Its false positive rate was 37.0%, against a target of 5%. | Its false positive rate was 2.8%, against a target of 5%. |
| Table 5.1, O2 evidence | MTTR was 21.53 s, against a target of 25 s (simulation mode). | MTTR was 37.00 s, against a target of 25 s (simulation mode). |
| Table 5.1, O3 evidence | 300 trials per condition, with Welch's t-test and Cohen's d for MTTD, MTTR and false positive rate. Containment had no test in Run 1, and the baseline was modelled. | 300 trials per condition, with Welch's t-test and Cohen's d for the times and the false positive rate and a two-proportion test for detection and containment. The baseline was run as software on the same traffic. |
| Table 5.1, Outcome column | Partly achieved / Achieved / Largely achieved / Achieved | Your judgement. Change a word only if the Run 2 numbers make the old word untrue. |
| Table 5.2, RQ1 answer | It detected attacks after 21.52 s on average, but it raised many false alarms (37.0%). The rate is too high for use without tuning. | 78.3% of the attacks raised an alert with AnDet Pro and 83.7% with the baseline. The mean time to detect was 37.00 s and the false positive rate 2.8%. |
| Table 5.2, RQ3 answer | Yes in Run 1: MTTD fell by 44.8% and MTTR by 72.1% (both p < 0.001). The baseline was modelled from published values. | In Run 2 the MTTD fell from 51.53 s to 37.00 s (−28.2%, p = 0.002) and the MTTR fell from 89.94 s to 37.00 s (−58.9%, p < 0.001). The baseline was run as software on the same traffic. (Start with Yes, Partly or No, as the hypothesis table in RESULTS_FOR_THESIS.md says.) |
| 5.3 Conclusions (first two bullets) | In Run 1 the response was in place after 21.53 seconds, against 77.13 seconds for the modelled baseline. Detection was faster than the baseline, but the 20-second target was not met. | In Run 2 the response was in place after 37.00 seconds, against 89.94 seconds for the baseline. The mean time to detect was 37.00 seconds; the 20-second target was not met. |
| 5.3 Conclusions (false alarms and containment) | The rate of 37.0% is above the baseline (21.0%) and far above the 5% target. Containment was 65.0%, well above the baseline (5.0%) but below the 90% target. | The false positive rate was 2.8% (baseline 22.9%; target 5%). Containment was 75.0% (baseline 75.3%; target 90%). |
| 5.3 Conclusions (last bullet) | The evidence is a first test. The baseline was modelled, the attacks were injected and the results come from one run, so the figures should not be taken as final. | The attacks were injected, the review time of a person in the baseline is assumed, one flow is taken as one second, and the results come from one data set and one trained model. |
| 5.4 Recommendation R8 | Do not claim that VMD lowers false alarms until it has been tested with and without VMD (reason given: Run 1 did not isolate the effect of VMD). | Use the "Model" table in section 8 of RESULTS_FOR_THESIS.md: it compares the model with VMD and without VMD. Keep R8 only if the difference is small or unclear. |
| 5.5 Limitations | In short, the baseline was modelled, the attacks were injected, the results come from one sample and one trained model, and the tests ran in simulation mode. | In short, the attacks were injected, the review time of a person in the baseline is assumed, one flow is taken as one second, the results come from one sample and one trained model, and the tests ran in simulation mode. |
| 5.6 Future Work | Run the complete evaluation and replace the Run 1 tables with its results. Compare thresholds ... Run the comparison with and without VMD, and vary the number of modes and the window length. | Delete the bullets for work that Run 2 did (the complete evaluation, thresholds on held-out data, the test without VMD, the window-length check if you ran it). Keep: real attack flows one type at a time, other detectors, a live controller. |
| Appendix A | excerpts of the source code that produced the Run 1 results | Keep the Run 1 excerpts, label them Run 1, and add excerpts from the rebuilt files andet/vmd.py, andet/model.py (calibrate), andet/trials.py and andet/policy.py, labelled Run 2. |

## B. Section 4.4.6 becomes "Run 2: The Complete Evaluation"

Rename the heading, delete the old text (it is in the future tense), and paste in this order. Every table is in RESULTS_FOR_THESIS.md under the section named here.

| Order | What | From | Suggested caption |
|---|---|---|---|
| 1 | One paragraph: what changed since Run 1 | section "What changed since Run 1" |  |
| 2 | Data table | section 1 | Table 4.7: Data used in Run 2 |
| 3 | Model and threshold table, then the training sentence | section 2 | Table 4.8: Model and threshold settings in Run 2 |
| 4 | Results table, then one paragraph each for MTTD, MTTR, false positive rate and containment | sections 3 and 5 | Table 4.9: Results of Run 2 (static baseline against AnDet Pro) |
| 5 | Figure: results against targets | figures/fig_results_vs_targets.png | Figure 4.5: Results of Run 2 against the targets |
| 6 | Requirements table and the sentence under it | section 4 | Table 4.10: Non-functional requirements checked against Run 2 |
| 7 | False alarm evidence: the small table, the table by part of the stream, the threshold sweep, and the draft wording | section 6 | Table 4.11: False alarms by part of the test stream |
| 8 | Figures: false alarms by part of the stream, risk scores, ROC curve | figures/fig_fpr_by_segment.png, fig_risk_distribution.png, fig_roc_curves.png | Figure 4.6, 4.7, 4.8 |
| 9 | Extra checks: with and without VMD, repeat training, window length, attack density | section 8 | Table 4.12: Extra checks |
| 10 | Time to score one window (NFR-05) | section 9 | Table 4.13: Time to score one window |

Not optional: the replay of the real test stream (section 7). Report it whatever it shows; it is the only check that does not inject anything. Optional: the detail table with confidence intervals (section 3, second table) and the hypothesis table (section 3, third table).

### Which checks listed in the old Section 4.4.6 did this run cover?

Delete from the new Section 4.4.6 every item that says No. The thesis must not claim a check that was not run.

| Item in the old Section 4.4.6 | In this run |
|---|---|
| The baseline is run as software on the same traffic | Yes |
| Every trial is saved; detection rate and time to detect are reported separately, with standard deviations and 95% confidence intervals | Yes |
| Containment is worked out from the rules the engine produces | Yes |
| Welch's t-test and the two-proportion test | Yes |
| The threshold is set on held-out normal data, and a sweep shows the effect of the threshold | Yes |
| VMD is switched off in one set of runs | Yes |
| A window-length sweep | No - not run in this mode: delete this item from Section 4.4.6, or run  python run.py --mode full |
| Repeated training with different seeds | No - not run in this mode: delete this item from Section 4.4.6, or run  python run.py --mode full |
| A timing test of one window (NFR-05) | Yes |
| (extra) VMD on blocks, closer to live use | No - optional |
| (extra) Different attack densities | No - optional |

## C. Wording that changes because the method changed

| Where | Now says | Change to |
|---|---|---|
| 3.4.2, after Equation 3.3 | In Run 1 the threshold was calculated from the normal training windows. Section 4.4.4 explains why this matters for the false alarm rate. | Add: In Run 2 it is calculated from a separate calibration block of normal windows that the model did not train on (10,371 flows, 15% of the normal training flows). |
| 3.6, last line before 3.6.2 | The complete evaluation (Section 4.4.6) also reports the detection rate ... | Run 2 (Section 4.4.6) also reports the detection rate ... (change "The complete evaluation" to "Run 2"). |
| 3.6.2 The Static Zero-Trust Baseline | In Run 1 its detection time, false alarm rate and containment were set from published values ... a modelled comparison, not a measured one. | Add: In Run 2 the baseline is run as software on the same traffic. It raises an alert when the mean of the last 10 flows of any feature is more than 3 standard deviations from its value on normal training traffic. The time a person needs to review an alert is an assumption (38 s on average, SD 5 s, as in Run 1); everything else is measured. |
| 3.6.3 Hypotheses and Statistical Tests | (tests listed there) | Add: In Run 2 the four p-values for H1 to H4 are adjusted with Holm's method, and Mann-Whitney, paired and Fisher tests are reported next to Welch's t-test and the two-proportion test as checks. |
| Table 4.2, Data loading | What it does: reads the file, scales to 0-1, splits by time. Main settings: 70/30 split; any numeric flow table | Main settings: first 70% in time for training, the rest for testing; normal training flows cut into fit / validation / calibration blocks (70/15/15%); scaler learned on the fit block only |
| Table 4.2, Baseline | What it does: Static rules with a fixed threshold, modelled on published values. Main settings: Values from the literature | What it does: Static rule on rolling means, run as software on the same traffic. Main settings: window 10, limit 3 standard deviations, review delay 38 s (assumed) |
| Table 4.2, Experiment runner | What it does: Runs the trials for both conditions and saves the results. Main settings: 10 scenarios × 30 repetitions, seed 42 | What it does: Builds trial streams from real flows, runs both conditions, saves every trial. Main settings: 10 scenarios × 30 repetitions, seed 42 |
| Table 4.2, Statistics | What it does: Welch's t-test, Cohen's d and confidence intervals. Main settings: α = 0.05 | What it does: Welch, Mann-Whitney, paired t, two-proportion z and Fisher tests; Cohen's d and h; Wilson and Newcombe intervals; Holm correction. Main settings: α = 0.05 |
| Table 4.2, new rows | (none) | Add: Features (sliding windows, VMD cache) and Report writer (tables, figures and records of Table 3.7). |
| 4.3 Testing | There are 48 automated tests ... All 48 tests passed in 72.40 seconds (Figure 4.3). | Run python -m pytest -q on your computer. Use the number of tests and the time it prints, and take a new screenshot for Figure 4.3. The new suite also checks the split and scaler (no test data used in training), the sliding windows, the baseline, the trial streams, the statistics functions and the report writer. |
| 4.4.4 False alarms, last two sentences | The complete evaluation tests this with a threshold sweep. ... Until these tests are done, this explanation is a likely cause and not a finding. | Section 4.4.6 reports these tests. The false alarm rate was 0.7% on held-out calibration windows and 0.5% on normal windows of the real test stream; in 0.0% of the trials at least half of the normal windows were flagged. State whether the sweep and the part-by-part table support the explanation; keep "likely cause" unless they settle it. |
| 4.4.5 Limits of the Evaluation | 1. Modelled baseline ... 4. Missing per-trial values ... 5. Threshold set on training data ... 7. No ablation or sweeps | Add after the list: Run 2 (Section 4.4.6) removes limits 1, 4, 5 and 7. Limit 3 still applies to the data set, and Run 2 trained one model for the main result. New limits of Run 2: the time a person takes to review an alert is assumed; one flow is taken as one second; VMD is computed over the whole stream, so a window can depend on flows that come after it (look-ahead check: 2.8% false alarms before the attack with VMD on the whole stream, 6.5% with VMD on past flows only); the data set has no IP addresses, so containment assumes the alert names the true attacker and harm to normal users is not measured. |
| Table 4.1 (environment) | Run 1 computer and versions | Add your Run 2 computer (the program prints it at the start and writes environment.json). It ran on: Linux-6.6.159+-x86_64-with-glibc2.39; Python 3.13.16; TensorFlow 2.21.0. |

## D. Slides (AnDet_Pro_Defense_Deck_v3.pptx)

The charts and tables on slides 16 to 19 are real PowerPoint charts and tables: click, then Edit Data, and type the numbers from section 10 of RESULTS_FOR_THESIS.md.

| Slide | What to change |
|---|---|
| 11 How It Was Tested | Sample size (100,319 flows), trials per condition (300), and the sentence about the baseline (run as software, review time assumed) |
| 12 Experimental Set-up | Same items; add one line: threshold set on held-out normal windows |
| 13, 14, 15, 20 Evidence | These show screenshots of the Run 1 console. Keep them and label them Run 1, or replace them with screenshots of the Run 2 console (training, policy log, pytest, result summary). |
| 16 Results at a Glance | The four tiles (MTTD, MTTR, containment, false positive rate) and, if you wish, the detection rate |
| 17, 18 Results charts | Chart data and the sentences beside them |
| 19 Summary Statistics | 300 trials per condition; the t, p and d values |
| 21 What the Results Mean, 23 Conclusion | Re-read each sentence against the new numbers |
| 22 Objectives | Targets met or missed (1 of the four performance targets were met) |
| 24 Limitations | Remove "Modelled baseline" and "threshold on training data"; add "review time of a person is assumed" and "one flow = one second" |
| 25 Recommendations | R8 (VMD) depends on the with and without VMD result |
| 29 (hidden) Requirements | 3 of the ten non-functional requirements were met, 3 were missed and 4 were not measured |
| Speaker notes and the Q&A sheet | Any number that is spoken |

## E. Still not measured after this run (say so in Chapter Five)

* The time to install a rule in a real switch (NFR-06): the policy engine ran in simulation mode.
* Up to 1,000 hosts (NFR-07), downtime (NFR-08) and the HTTPS link to the controller (NFR-10).
* Harm to normal users from blocking: the data set has no IP addresses.
* Slow attacks that look normal, and any data set other than NF-CSE-CIC-IDS2018.
* Live capture: the Run 1 capture code (src/utils/live_capture.py) builds five per-second summary values, not the ten flow features of the trained model, so it has not been connected to this model.
* Not run in this mode: other window lengths, repeated training with other seeds. Say so as a limit, or run  python run.py --mode full.

## F. Last checks before you submit

* Every number in the Abstract, Chapter One, the chapter summary and Chapter Five equals the number in the Run 2 tables.
* Every "Run 1" number is still labelled Run 1, and every Run 2 number is labelled Run 2.
* Ctrl+A, then F9, then "Update entire table" (contents, list of figures, list of tables).
* Open the slides and check that nothing says 300 trials, 38.98, 21.52, 77.13 or 37.0% unless it is labelled Run 1.